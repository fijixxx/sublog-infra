"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = __importStar(require("aws-sdk"));
const markdown = require("markdown-it");
const shiki = require("shiki");
const util_1 = require("util");
exports.handler = async (event) => {
    /**
     * 空メッセージ(空 messegaeId, body)を取得した場合にエラーを吐かないように、
     * for などを使って取得するとよいらしい
     */
    console.log(event);
    for (const { messageId, body } of event.Records) {
        console.log("messageId: " + messageId);
        const parsedSQSBody = JSON.parse(body);
        const id = parsedSQSBody.id;
        console.log("articleId: " + id);
        /**
         * event.Records[*].body.id から記事を取得
         */
        AWS.config.update({ region: "ap-northeast-1" });
        const client = new AWS.DynamoDB.DocumentClient();
        const params = {
            TableName: "sublog",
            KeyConditionExpression: "id = :id",
            ExpressionAttributeValues: {
                ":id": id,
            },
        };
        const response = await client
            .query(params)
            .promise()
            .catch((e) => e);
        const articles = dataMapper(response);
        const articleData = articles[0];
        /**
         * 取得した記事から fileName を使って text.md の中身を取得
         */
        const secretsClient = new AWS.SecretsManager();
        const bucketName = await secretsClient.getSecretValue({ SecretId: 'sublog_assets_bucket_name' })
            .promise()
            .then((data) => {
            if (data.SecretString) {
                return JSON.parse(data.SecretString).name;
            }
        })
            .catch((e) => e);
        const s3Client = new AWS.S3();
        const targetObject = await s3Client.getObject({
            Bucket: bucketName,
            Key: "text/" + articleData.fileName + '.md'
        })
            .promise()
            .catch((e) => e);
        const decoder = new util_1.TextDecoder();
        const decodedBody = decoder.decode(targetObject.Body);
        const highlightClient = (await shiki.getHighlighter({ theme: 'nord' }));
        /**
         * codeToHtml にモンキーパッチするか何かが必要
         */
        const md = markdown({ html: true, highlight: (code, lang) => { return highlightClient.codeToHtml(code, lang); } });
        const parsedHtml = md.render(decodedBody);
        const updateParams = {
            TableName: "sublog",
            Key: {
                id: id,
            },
            UpdateExpression: "set body = :body",
            ExpressionAttributeValues: {
                ":body": parsedHtml,
            },
            ReturnValues: 'ALL_NEW'
        };
        const updateResult = await client
            .update(updateParams)
            .promise()
            .catch((e) => e);
        console.log(updateResult);
    }
    return true;
};
/**
 * DynamoDB クエリ結果のマッパー
 * @param _response - DynamoDB のクエリレスポンス
 */
const dataMapper = (_response) => {
    const data = _response.Items.map((item) => ({
        id: item.id || '',
        createdAt: item.createdAt || '',
        fileName: item.fileName || '',
        category: item.category || '',
        media: item.media || '',
        title: item.title || '',
        eyeCatchURL: item.eyeCatchURL || '',
        tag: item.tag || [''],
        updatedAt: item.updatedAt || '',
    }));
    return data;
};
